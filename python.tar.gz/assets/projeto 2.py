print("CONVERTOR DE TEMPERATURA")
print("1 - Celsius para Fahrenheit")
print("2 - Fahrenheit para Celsius")
CELSIUS_TO_FAHRENHEIT = 1
FAHRENHEIT_TO_CELSIUS = 2
opcao = int(input("Digite a opção desejada: "))
# Conversion formulas
# Fahrenheit to Celsius: (Fahrenheit - 32) * 5/9
# Celsius to Fahrenheit: (Celsius * 9/5) + 32
if opcao == 1:
    Celsius = float(input("Digite a temperatura em Celsius: "))
    Fahrenheit = (Celsius * 9/5) + 32
    print("A temperatura em Fahrenheit é: ", Fahrenheit)
elif opcao == 2:
    Fahrenheit = float(input("Digite a temperatura em Fahrenheit: "))
    Celsius = 5/9 * (Fahrenheit - 32)
    print("A temperatura em Celsius é: ", Celsius)
    