import math
import os
import random
import struct
import sys
import pygame

# ------------------------------------------------------------------
# CONFIGURAÇÕES E INICIALIZAÇÃO
# ------------------------------------------------------------------
pygame.init()
pygame.font.init()

audio_disponivel = True
try:
    pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
except Exception:
    audio_disponivel = False

LARGURA, ALTURA = 600, 680
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Para a minha Luana")

# ------------------------------------------------------------------
# GERADOR DE EFEITOS SONOROS PROCEDURAIS (SEM ARQUIVOS EXTERNOS)
# ------------------------------------------------------------------
def gerar_som_procedural(tipo):
    if not audio_disponivel:
        return None
    try:
        sample_rate = 44100
        buffer = bytearray()

        if tipo == "pop":
            duracao = 0.08
            n_samples = int(sample_rate * duracao)
            for i in range(n_samples):
                t = i / sample_rate
                freq = 600 - (t / duracao) * 400
                val = int(32767 * math.sin(2 * math.pi * freq * t) * (1 - t / duracao))
                buffer.extend(struct.pack("<h", val))

        elif tipo == "papel":
            duracao = 0.25
            n_samples = int(sample_rate * duracao)
            for i in range(n_samples):
                t = i / sample_rate
                val = int(12000 * (random.random() * 2 - 1) * (1 - t / duracao))
                buffer.extend(struct.pack("<h", val))

        elif tipo == "fanfarra":
            duracao = 0.6
            n_samples = int(sample_rate * duracao)
            for i in range(n_samples):
                t = i / sample_rate
                freq = 523.25 if t < 0.2 else (659.25 if t < 0.4 else 783.99)
                val = int(20000 * math.sin(2 * math.pi * freq * t) * (1 - (t % 0.2) / 0.2))
                buffer.extend(struct.pack("<h", val))

        sound = pygame.mixer.Sound(buffer=bytes(buffer))
        sound.set_volume(0.3)
        return sound
    except Exception:
        return None

sfx_pop = gerar_som_procedural("pop")
sfx_papel = gerar_som_procedural("papel")
sfx_fanfarra = gerar_som_procedural("fanfarra")

def tocar_sfx(sfx):
    if sfx and audio_disponivel:
        sfx.play()

# Cores
COR_FUNDO_CINEMA = (20, 8, 15)
COR_FUNDO_CLARO = (255, 230, 238)
COR_CARD = (255, 255, 255)
COR_CARD_PEDIDO = (255, 242, 246)
COR_PAPEL_CARTA = (255, 250, 240)
COR_ROSA_FORTE = (235, 40, 110)
COR_ROSA_DOCE = (255, 130, 169)
COR_VINHO = (140, 15, 45)
COR_TEXTO_CARTA = (70, 35, 45)
COR_TEXTO = (50, 50, 50)
COR_SIM = (46, 184, 92)
COR_NAO = (220, 53, 69)

# Fontes Compatíveis Universais
fnt_abertura = pygame.font.SysFont("georgia", 22, italic=True)
fnt_titulo = pygame.font.SysFont("segoe ui", 22, bold=True)
fnt_carta = pygame.font.SysFont("georgia", 16, italic=True)
fnt_casal = pygame.font.SysFont("comic sans ms", 24, bold=True)
fnt_fofa = pygame.font.SysFont("comic sans ms", 15, bold=True)
fnt_balao = pygame.font.SysFont("segoe ui", 13, bold=True)

# Carregar Mídia
if audio_disponivel and os.path.exists("musica.mp3"):
    try:
        pygame.mixer.music.load("musica.mp3")
        pygame.mixer.music.play(-1)
        pygame.mixer.music.set_volume(0.4)
    except Exception:
        pass

foto_carregada = None
for nome_foto in ["foto.jpg", "foto.png", "foto.jpeg"]:
    if os.path.exists(nome_foto):
        try:
            img_orig = pygame.image.load(nome_foto)
            foto_carregada = pygame.transform.smoothscale(img_orig, (180, 180))
            break
        except Exception:
            pass

# ------------------------------------------------------------------
# FRASES DO BOTÃO NÃO E BALÕES DO URSINHO
# ------------------------------------------------------------------
frases_provocacoes = [
    "Não",
    "TEM CERTEZA?",
    "PENSA MELHOR...",
    "AINDA NÃO?",
    "OLHA O SIM",
    "Não faz isso comigo...",
    "Aperta o verde!",
    "Errou de novo!",
    "Eu sou rápido!",
    "Tá bom, desisto... mentira!"
]

fala_ursinho = [
    "O botao verde é tão mais bonito...",
    "Acho que seu mouse deu uma escorregada!",
    "Tenta de novo, só que no verde!",
    "Prometo que o SIM tem surpresa!",
    "Ainda tentando o Não? Eu sou persistente!"
]

# ------------------------------------------------------------------
# PARTÍCULAS E CONFETES
# ------------------------------------------------------------------
particulas = [
    {
        "x": random.randint(0, LARGURA),
        "y": random.randint(-600, 0),
        "tam": random.randint(3, 7),
        "vel": random.uniform(1.0, 2.2),
        "cor": random.choice([(255, 105, 180), (235, 40, 110), (255, 182, 193)]),
    }
    for _ in range(45)
]

confetes = []

def disparar_explosao_coracoes():
    confetes.clear()
    for _ in range(150):
        ang = random.uniform(0, 2 * math.pi)
        vel = random.uniform(3, 12)
        confetes.append({
            "x": LARGURA // 2,
            "y": ALTURA // 2,
            "vx": math.cos(ang) * vel,
            "vy": math.sin(ang) * vel - 3,
            "cor": random.choice([(255, 20, 147), (255, 0, 80), (255, 215, 0), (220, 20, 60), (255, 105, 180)]),
            "tam": random.randint(4, 9),
            "vida": 255,
        })

def desenhar_particulas_fundo():
    for p in particulas:
        p["y"] += p["vel"]
        if p["y"] > ALTURA:
            p["y"] = -20
            p["x"] = random.randint(0, LARGURA)

        pygame.draw.circle(tela, p["cor"], (int(p["x"]), int(p["y"])), p["tam"])

def atualizar_desenhar_confetes():
    for c in confetes[:]:
        c["x"] += c["vx"]
        c["y"] += c["vy"]
        c["vy"] += 0.2
        c["vida"] -= 3.0
        if c["vida"] <= 0:
            confetes.remove(c)
        else:
            s_c = pygame.Surface((c["tam"]*2, c["tam"]*2), pygame.SRCALPHA)
            pygame.draw.circle(s_c, (*c["cor"], max(0, int(c["vida"]))), (c["tam"], c["tam"]), c["tam"])
            tela.blit(s_c, (c["x"], c["y"]))

# ------------------------------------------------------------------
# DESENHO DE CORAÇÃO E BRILHO/ESTRELA VETORIAL
# ------------------------------------------------------------------
def desenhar_coracao(surface, x, y, tamanho, cor=(255, 40, 80)):
    pontos = []
    for i in range(0, 360, 5):
        rad = math.radians(i)
        r_x = 16 * (math.sin(rad) ** 3)
        r_y = -(13 * math.cos(rad) - 5 * math.cos(2*rad) - 2 * math.cos(3*rad) - math.cos(4*rad))
        pontos.append((x + r_x * (tamanho / 16.0), y + r_y * (tamanho / 16.0)))
    if len(pontos) > 2:
        pygame.draw.polygon(surface, cor, pontos)

def desenhar_brilho(surface, x, y, tamanho, cor=(255, 215, 0)):
    raio_ext = tamanho
    raio_int = tamanho * 0.35
    pontos = []
    for i in range(8):
        ang = i * (math.pi / 4)
        r = raio_ext if i % 2 == 0 else raio_int
        pontos.append((x + r * math.cos(ang), y + r * math.sin(ang)))
    
    pygame.draw.polygon(surface, cor, pontos)
    pygame.draw.circle(surface, (255, 255, 255), (int(x), int(y)), int(raio_int * 0.6))

# ------------------------------------------------------------------
# MASCOTE URSINHO
# ------------------------------------------------------------------
def desenhar_ursinho(surface, cx, cy, escala_cora=1.0, fala=None):
    # Orelhas
    pygame.draw.circle(surface, (180, 115, 70), (cx - 32, cy - 28), 16)
    pygame.draw.circle(surface, (230, 175, 140), (cx - 32, cy - 28), 9)
    pygame.draw.circle(surface, (180, 115, 70), (cx + 32, cy - 28), 16)
    pygame.draw.circle(surface, (230, 175, 140), (cx + 32, cy - 28), 9)

    # Cabeça
    pygame.draw.circle(surface, (195, 128, 80), (cx, cy), 36)

    # Focinho e Bochechas
    pygame.draw.ellipse(surface, (245, 220, 200), (cx - 16, cy - 4, 32, 24))
    pygame.draw.ellipse(surface, (60, 35, 20), (cx - 6, cy - 2, 12, 8))
    pygame.draw.circle(surface, (40, 20, 10), (cx - 14, cy - 10), 4)
    pygame.draw.circle(surface, (40, 20, 10), (cx + 14, cy - 10), 4)
    pygame.draw.circle(surface, (255, 150, 170), (cx - 20, cy + 4), 6)
    pygame.draw.circle(surface, (255, 150, 170), (cx + 20, cy + 4), 6)

    # Coração
    desenhar_coracao(surface, cx, cy + 28, int(12 * escala_cora), (235, 30, 70))

    # Balão de fala
    if fala:
        img_fala = fnt_balao.render(fala, True, COR_VINHO)
        w_b, h_b = img_fala.get_width() + 20, img_fala.get_height() + 12
        bx, by = cx - w_b // 2, cy - 75
        pygame.draw.rect(surface, (255, 255, 255), (bx, by, w_b, h_b), border_radius=10)
        pygame.draw.rect(surface, COR_ROSA_DOCE, (bx, by, w_b, h_b), 2, border_radius=10)
        pygame.draw.polygon(surface, (255, 255, 255), [(cx - 6, by + h_b), (cx + 6, by + h_b), (cx, by + h_b + 6)])
        surface.blit(img_fala, (bx + 10, by + 6))

# ------------------------------------------------------------------
# CLASSE DE BOTÕES
# ------------------------------------------------------------------
class Botao:
    def __init__(self, x, y, w, h, texto, cor_base):
        self.x = float(x)
        self.y = float(y)
        self.vx = 0.0
        self.vy = 0.0
        self.w = float(w)
        self.h = float(h)
        self.texto = texto
        self.cor_base = cor_base
        self.tentativas = 0
        self.ultimo_troca_tempo = 0

    def desenhar(self, surface, pos_mouse, alpha=255, auto_ajustar=False, destaque=False):
        fnt_btn = pygame.font.SysFont("segoe ui", 15, bold=True)
        if auto_ajustar:
            largura_texto = fnt_btn.render(self.texto, True, (255, 255, 255)).get_width()
            self.w = max(120, largura_texto + 32)

        rect = pygame.Rect(int(self.x), int(self.y), int(self.w), int(self.h))
        hover = rect.collidepoint(pos_mouse)

        cor = self.cor_base
        if hover:
            cor = (min(cor[0] + 30, 255), min(cor[1] + 30, 255), min(cor[2] + 30, 255))

        # Sombra
        surf_sombra = pygame.Surface((int(self.w), int(self.h)), pygame.SRCALPHA)
        pygame.draw.rect(surf_sombra, (0, 0, 0, int(30 * (alpha / 255))), surf_sombra.get_rect(), border_radius=15)
        surface.blit(surf_sombra, (int(self.x) + 3, int(self.y) + 4))

        # Botão
        surf_btn = pygame.Surface((int(self.w), int(self.h)), pygame.SRCALPHA)
        pygame.draw.rect(surf_btn, (*cor, alpha), surf_btn.get_rect(), border_radius=15)
        if destaque:
            pygame.draw.rect(surf_btn, (255, 215, 0, alpha), surf_btn.get_rect(), 3, border_radius=15)
        surface.blit(surf_btn, (int(self.x), int(self.y)))

        txt_img = fnt_btn.render(self.texto, True, (255, 255, 255))
        txt_img.set_alpha(alpha)
        surface.blit(txt_img, txt_img.get_rect(center=rect.center))

    def fugir_suave(self, pos_mouse, tempo_atual):
        cx = self.x + self.w / 2
        cy = self.y + self.h / 2
        dist = math.hypot(pos_mouse[0] - cx, pos_mouse[1] - cy)

        if dist < 120 and dist > 0:
            forca = (120 - dist) / 120 * 5.5
            self.vx += ((cx - pos_mouse[0]) / dist) * forca
            self.vy += ((cy - pos_mouse[1]) / dist) * forca
            
            if tempo_atual - self.ultimo_troca_tempo > 1.2:
                self.registrar_tentativa(tempo_atual)

        self.x += self.vx
        self.y += self.vy
        self.vx *= 0.82
        self.vy *= 0.82

        margem_esq, margem_dir = 50, LARGURA - self.w - 50
        margem_top, margem_bot = 220, ALTURA - self.h - 50

        if self.x < margem_esq:
            self.x = margem_esq
            self.vx = abs(self.vx) + 2.0
        elif self.x > margem_dir:
            self.x = margem_dir
            self.vx = -abs(self.vx) - 2.0

        if self.y < margem_top:
            self.y = margem_top
            self.vy = abs(self.vy) + 2.0
        elif self.y > margem_bot:
            self.y = margem_bot
            self.vy = -abs(self.vy) - 2.0

    def registrar_tentativa(self, tempo_atual):
        self.tentativas += 1
        self.ultimo_troca_tempo = tempo_atual
        idx = min(self.tentativas, len(frases_provocacoes) - 1)
        self.texto = frases_provocacoes[idx]
        tocar_sfx(sfx_pop)

# ------------------------------------------------------------------
# CONTEÚDOS DAS ETAPAS
# ------------------------------------------------------------------
mensagem_carta = [
  "Quem diria que aquele primeiro 'oi' me traria",
    "alguém tão especial pra minha vida?",
    "",
    "Aquele pouco tempo juntos mudou tudo de vez.",
    "Bastaram alguns momentos pra eu ver a mulher",
    "linda, incrível e madura que você é.",
    "",
    "Amo te ouvir falar e rir com você!",
    "Fico só te admirando. E a saudade aqui é gigante.",
    "No fundo, a gente já é um do outro há muito tempo.",
    "",
    "Fiz isso pra marcar o nosso começo de um jeito único!"
]

memorias = [
    "1) O primeiro 'oi' que mudou tudo...",
    "2) As risadas que a distância não conseguiu segurar...",
    "3) O frio na barriga quando nos encontramos..."
]
idx_memoria = 0

estrelas_game = [
    {"x": 120, "y": 280, "coletada": False},
    {"x": 300, "y": 180, "coletada": False},
    {"x": 480, "y": 280, "coletada": False}
]

# ------------------------------------------------------------------
# ESTADOS E BOTÕES
# ------------------------------------------------------------------
etapa = 1
alpha_fade = 0
fade_in = True
tempo_estado = 0.0

btn_continuar = Botao(200, 480, 200, 50, "Continuar", COR_ROSA_FORTE)
btn_memoria = Botao(180, 480, 240, 50, "Próxima Lembrança", COR_ROSA_FORTE)
btn_abrir_carta = Botao(160, 500, 280, 50, "ABRIR MEU CORACAO", COR_VINHO)

btn_sim = Botao(140, 420, 140, 52, "SIM", COR_SIM)
btn_nao = Botao(320, 420, 140, 52, "Nao", COR_NAO)

relogio = pygame.time.Clock()
rodando = True

# ------------------------------------------------------------------
# LOOP PRINCIPAL
# ------------------------------------------------------------------
while rodando:
    dt = relogio.tick(60) / 1000.0
    pos_mouse = pygame.mouse.get_pos()
    tempo_estado += dt

    if fade_in:
        alpha_fade = min(255, alpha_fade + 10)
    else:
        alpha_fade = max(0, alpha_fade - 14)

    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            rodando = False

        if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
            if etapa == 1 and alpha_fade >= 150:
                all_coletadas = all(e["coletada"] for e in estrelas_game)
                if not all_coletadas:
                    for e in estrelas_game:
                        if not e["coletada"] and math.hypot(pos_mouse[0] - e["x"], pos_mouse[1] - e["y"]) < 30:
                            e["coletada"] = True
                            tocar_sfx(sfx_pop)
                else:
                    rect = pygame.Rect(int(btn_continuar.x), int(btn_continuar.y), int(btn_continuar.w), int(btn_continuar.h))
                    if rect.collidepoint(pos_mouse):
                        tocar_sfx(sfx_papel)
                        fade_in = False

            elif etapa == 2 and alpha_fade >= 150:
                rect = pygame.Rect(int(btn_memoria.x), int(btn_memoria.y), int(btn_memoria.w), int(btn_memoria.h))
                if rect.collidepoint(pos_mouse):
                    tocar_sfx(sfx_pop)
                    idx_memoria += 1
                    if idx_memoria >= len(memorias):
                        fade_in = False

            elif etapa == 3 and alpha_fade >= 150:
                env_x, env_y = LARGURA // 2, 315
                dist_selo = math.hypot(pos_mouse[0] - env_x, pos_mouse[1] - env_y)
                if dist_selo < 40:
                    tocar_sfx(sfx_papel)
                    fade_in = False

            elif etapa == 4 and alpha_fade >= 150:
                rect = pygame.Rect(int(btn_abrir_carta.x), int(btn_abrir_carta.y), int(btn_abrir_carta.w), int(btn_abrir_carta.h))
                if rect.collidepoint(pos_mouse):
                    tocar_sfx(sfx_papel)
                    fade_in = False

            elif etapa == 5 and alpha_fade >= 150:
                rect_s = pygame.Rect(int(btn_sim.x), int(btn_sim.y), int(btn_sim.w), int(btn_sim.h))
                rect_n = pygame.Rect(int(btn_nao.x), int(btn_nao.y), int(btn_nao.w), int(btn_nao.h))

                if rect_s.collidepoint(pos_mouse):
                    tocar_sfx(sfx_fanfarra)
                    disparar_explosao_coracoes()
                    etapa = 6
                    fade_in = True
                    tempo_estado = 0
                elif rect_n.collidepoint(pos_mouse):
                    btn_nao.registrar_tentativa(tempo_estado)
                    btn_nao.vx += random.choice([-8.0, 8.0])
                    btn_nao.vy += random.choice([-8.0, 8.0])

    if not fade_in and alpha_fade <= 0:
        etapa += 1
        fade_in = True
        tempo_estado = 0

    # ------------------------------------------------------------------
    # RENDERIZAÇÃO
    # ------------------------------------------------------------------
    if etapa == 1:
        tela.fill(COR_FUNDO_CINEMA)
        desenhar_particulas_fundo()

        txt = fnt_abertura.render("Para alguem especial...", True, (255, 220, 230))
        txt.set_alpha(alpha_fade)
        tela.blit(txt, txt.get_rect(center=(LARGURA // 2, 80)))

        todas = all(e["coletada"] for e in estrelas_game)
        for e in estrelas_game:
            if not e["coletada"]:
                escala_e = 1.0 + math.sin(tempo_estado * 3) * 0.15
                desenhar_brilho(tela, e["x"], e["y"], int(18 * escala_e), (255, 215, 0))
            else:
                desenhar_brilho(tela, e["x"], e["y"], 12, COR_ROSA_FORTE)

        lbl_dica = fnt_fofa.render("Colete os 3 brilhos para desbloquear!" if not todas else "Tudo desbloqueado! Clique abaixo", True, (255, 200, 220))
        lbl_dica.set_alpha(alpha_fade)
        tela.blit(lbl_dica, lbl_dica.get_rect(center=(LARGURA // 2, 380)))

        if todas:
            btn_continuar.desenhar(tela, pos_mouse, alpha_fade, destaque=True)

    elif etapa == 2:
        tela.fill(COR_FUNDO_CLARO)
        desenhar_particulas_fundo()

        s_card = pygame.Surface((480, 360), pygame.SRCALPHA)
        pygame.draw.rect(s_card, (*COR_CARD, alpha_fade), s_card.get_rect(), border_radius=25)
        tela.blit(s_card, (60, 100))

        lbl = fnt_titulo.render("Memórias", True, COR_VINHO)
        lbl.set_alpha(alpha_fade)
        tela.blit(lbl, lbl.get_rect(center=(LARGURA // 2, 140)))

        txt_mem = memorias[min(idx_memoria, len(memorias) - 1)]
        img_mem = fnt_carta.render(txt_mem, True, COR_TEXTO)
        img_mem.set_alpha(alpha_fade)
        tela.blit(img_mem, img_mem.get_rect(center=(LARGURA // 2, 260)))

        btn_memoria.desenhar(tela, pos_mouse, alpha_fade)

    elif etapa == 3:
        tela.fill(COR_FUNDO_CLARO)
        desenhar_particulas_fundo()

        s_card = pygame.Surface((480, 420), pygame.SRCALPHA)
        pygame.draw.rect(s_card, (*COR_CARD, alpha_fade), s_card.get_rect(), border_radius=25)
        tela.blit(s_card, (60, 100))

        lbl = fnt_titulo.render("Há uma carta esperando por você...", True, COR_VINHO)
        lbl.set_alpha(alpha_fade)
        tela.blit(lbl, lbl.get_rect(center=(LARGURA // 2, 160)))

        env_x, env_y = LARGURA // 2 - 120, 230
        pygame.draw.rect(tela, (235, 220, 200), (env_x, env_y, 240, 160), border_radius=12)
        pygame.draw.line(tela, (180, 150, 120), (env_x, env_y), (env_x + 120, env_y + 85), 2)
        pygame.draw.line(tela, (180, 150, 120), (env_x + 240, env_y), (env_x + 120, env_y + 85), 2)

        escala = 1.0 + math.sin(tempo_estado * 3) * 0.15
        desenhar_coracao(tela, env_x + 120, env_y + 85, int(18 * escala), (220, 20, 50))

        lbl_clique = fnt_fofa.render("(Clique no selo de coração para abrir!)", True, COR_ROSA_FORTE)
        lbl_clique.set_alpha(alpha_fade)
        tela.blit(lbl_clique, lbl_clique.get_rect(center=(LARGURA // 2, 440)))

    elif etapa == 4:
        tela.fill(COR_FUNDO_CLARO)
        desenhar_particulas_fundo()

        s_card = pygame.Surface((520, 600), pygame.SRCALPHA)
        pygame.draw.rect(s_card, (*COR_PAPEL_CARTA, alpha_fade), s_card.get_rect(), border_radius=20)
        tela.blit(s_card, (40, 30))

        pygame.draw.rect(tela, COR_ROSA_DOCE, (48, 38, 504, 584), 2, border_radius=16)
        pygame.draw.rect(tela, COR_ROSA_FORTE, (52, 42, 496, 576), 1, border_radius=14)

        desenhar_coracao(tela, 68, 58, 8, COR_ROSA_FORTE)
        desenhar_coracao(tela, 532, 58, 8, COR_ROSA_FORTE)

        lbl_c = fnt_titulo.render("De: Luis  |  Para: Luana", True, COR_VINHO)
        lbl_c.set_alpha(alpha_fade)
        tela.blit(lbl_c, lbl_c.get_rect(center=(LARGURA // 2, 75)))

        pygame.draw.line(tela, COR_ROSA_DOCE, (120, 100), (LARGURA - 120, 100), 2)

        y_lin = 135
        for linha in mensagem_carta:
            t = fnt_carta.render(linha, True, COR_TEXTO_CARTA)
            t.set_alpha(alpha_fade)
            tela.blit(t, t.get_rect(center=(LARGURA // 2, y_lin)))
            y_lin += 32

        btn_abrir_carta.desenhar(tela, pos_mouse, alpha_fade)

    elif etapa == 5:
        tela.fill(COR_FUNDO_CLARO)
        desenhar_particulas_fundo()

        s_card = pygame.Surface((500, 480), pygame.SRCALPHA)
        pygame.draw.rect(s_card, (*COR_CARD_PEDIDO, alpha_fade), s_card.get_rect(), border_radius=25)
        tela.blit(s_card, (50, 90))

        idx_fala = min(btn_nao.tentativas, len(fala_ursinho) - 1)
        fala_curr = fala_ursinho[idx_fala] if btn_nao.tentativas > 0 else None
        desenhar_ursinho(tela, LARGURA // 2, 160, escala_cora=1.0, fala=fala_curr)

        lbl_nome = fnt_titulo.render("Luana,", True, COR_ROSA_FORTE)
        lbl_nome.set_alpha(alpha_fade)
        tela.blit(lbl_nome, lbl_nome.get_rect(center=(LARGURA // 2, 250)))

        perg = fnt_titulo.render("Quer namorar comigo?", True, COR_VINHO)
        perg.set_alpha(alpha_fade)
        tela.blit(perg, perg.get_rect(center=(LARGURA // 2, 290)))

        btn_nao.fugir_suave(pos_mouse, tempo_estado)

        nivel_sim = min(btn_nao.tentativas, 4)
        btn_sim.w = 140 + nivel_sim * 16
        btn_sim.h = 52 + nivel_sim * 5

        btn_sim.desenhar(tela, pos_mouse, alpha_fade, destaque=(btn_nao.tentativas > 0))
        btn_nao.desenhar(tela, pos_mouse, alpha_fade, auto_ajustar=True)

    elif etapa == 6:
        tela.fill(COR_FUNDO_CLARO)
        atualizar_desenhar_confetes()

        lbl_cel = fnt_casal.render("Sabia que ia aceitar hehe, agora é oficial !!!", True, COR_ROSA_FORTE)
        lbl_cel.set_alpha(alpha_fade)
        tela.blit(lbl_cel, lbl_cel.get_rect(center=(LARGURA // 2, ALTURA // 2)))

        if tempo_estado > 3.0:
            etapa = 7
            tempo_estado = 0

    elif etapa == 7:
        tela.fill(COR_FUNDO_CLARO)
        desenhar_particulas_fundo()
        atualizar_desenhar_confetes()

        s_card = pygame.Surface((520, 560), pygame.SRCALPHA)
        pygame.draw.rect(s_card, (*COR_CARD, alpha_fade), s_card.get_rect(), border_radius=30)
        tela.blit(s_card, (40, 50))

        pygame.draw.rect(tela, COR_ROSA_DOCE, (48, 58, 504, 544), 3, border_radius=26)

        escala_c = 1.0 + math.sin(tempo_estado * 3) * 0.15
        desenhar_ursinho(tela, LARGURA // 2, 130, escala_cora=escala_c)

        if foto_carregada:
            foto_s = foto_carregada.copy()
            foto_s.set_alpha(alpha_fade)
            tela.blit(foto_s, foto_s.get_rect(center=(LARGURA // 2, 285)))

            pygame.draw.rect(tela, COR_ROSA_FORTE, (LARGURA // 2 - 93, 192, 186, 186), 3, border_radius=16)
            desenhar_coracao(tela, LARGURA // 2 - 93, 192, 8, COR_ROSA_FORTE)
            desenhar_coracao(tela, LARGURA // 2 + 93, 192, 8, COR_ROSA_FORTE)
            y_base = 410
        else:
            y_base = 240

        t1 = fnt_fofa.render("Mesmo de longe, meu coração é inteirinho seu.", True, COR_TEXTO)
        t2 = fnt_fofa.render("Que este seja o início da nossa história,", True, COR_TEXTO)
        t3 = fnt_fofa.render("repleta de risadas, amor e momentos juntos!", True, COR_TEXTO)

        for txt, y_off in zip([t1, t2, t3], [0, 28, 56]):
            txt.set_alpha(alpha_fade)
            tela.blit(txt, txt.get_rect(center=(LARGURA // 2, y_base + y_off)))

        casal = fnt_casal.render("Luana & Luis", True, COR_ROSA_FORTE)
        casal.set_alpha(alpha_fade)
        tela.blit(casal, casal.get_rect(center=(LARGURA // 2, y_base + 112)))

    pygame.display.flip()

pygame.quit()
sys.exit()