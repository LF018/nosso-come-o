
print("CADASTRO :")
Cpf= int(input("digite seu cpf (APENAS NÚMEROS):"))
name = input("digite seu nome:")
if name.isdigit():
    print("ERROR")
else: 
    idade = int(input("digite sua idade:"))
    if idade < 18:
        print("ACESSO NEGADO")
    else:
        print("ACESSO PERMITIDO")
        print("Deseja continuar?")
        resposta = input()
        if resposta.lower() == "não":
            print("Processo Interrompido.")
        else:
            print("DADOS PREENCHIDOS COM SUCESSO")

      
