import asyncio
import random

class ProcessadorComplexo:
    def __init__(self, id_processo: int):
        self.id = id_processo

    async def executar_tarefa(self, carga_dados: dict) -> dict:
        """Simula uma operação assíncrona complexa com E/S bloqueante."""
        tempo_simulado = random.uniform(0.5, 2.0)
        await asyncio.sleep(tempo_simulado)
        
        # Processamento e cálculo de métrica
        resultado = carga_dados["valor"] * 1.5
        
        return {
            "id_processo": self.id,
            "tempo_execucao": round(tempo_simulado, 2),
            "resultado_calculo": resultado
        }

async def orquestrador_tarefas(num_tarefas: int):
    """Gerencia e executa múltiplas tarefas assíncronas concorrentemente."""
    processadores = [ProcessadorComplexo(i) for i in range(num_tarefas)]
    
    # Criando um lote de chamadas assíncronas
    tarefas = [
        proc.executar_tarefa({"valor": random.randint(10, 100)}) 
        for proc in processadores
    ]
    
    # Executa todas as tarefas simultaneamente e aguarda a conclusão
    resultados = await asyncio.gather(*tarefas)
    return resultados

# Ponto de entrada para a execução do código assíncrono
if __name__ == "__main__":
    quantidade_tarefas = 5
    
    # Executa o laço de eventos do asyncio
    resultados_finais = asyncio.run(orquestrador_tarefas(quantidade_tarefas))
    
    for res in resultados_finais:
        print(f"Processo {res['id_processo']} | Tempo: {res['tempo_execucao']}s | Resultado: {res['resultado_calculo']}")
